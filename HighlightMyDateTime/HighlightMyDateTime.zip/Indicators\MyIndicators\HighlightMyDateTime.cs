#region Using declarations
using System;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using Microsoft.VisualBasic.FileIO;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.MyIndicators
{
	public class HighlightMyDateTime : Indicator
	{
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Master: Reads all vertical line objects from chart, writes their data to a CSV file. Slave: Reads this CSV file, plots all vertical lines from it.";
				Name										= "HighlightMyDateTime";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				IsAutoScale									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				ModeMaster									= false;
				GroupID										= 1;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			// call the base.OnRender() to ensure standard Plots work as designed
			base.OnRender(chartControl, chartScale);
		
			string csvFile = Path.GetTempPath() + "HighlightMyDateTime_" + GroupID.ToString() + ".csv";
			if (ModeMaster) {
				bool firstItem = true;
				foreach (DrawingTool draw in DrawObjects.ToList()) {
					if (draw is VerticalLine) {
						VerticalLine myLine = draw as VerticalLine;
						var converter = new System.Windows.Media.BrushConverter();
						string newCsvLine = string.Format("{0},{1},{2},{3},{4},{5}", myLine.StartAnchor.Time.ToString("yyyyMMddHHmmss"), "HighlightMyDateTime_" + myLine.Tag, myLine.Stroke.Brush, (int)myLine.Stroke.DashStyleHelper, myLine.Stroke.Width, myLine.Stroke.Opacity);
						if (firstItem) {
							File.WriteAllText(csvFile, newCsvLine + Environment.NewLine);
							firstItem = false;
							continue;
						}
						File.AppendAllText(csvFile, newCsvLine + Environment.NewLine);
					}
				}
			} else {
				foreach (DrawingTool draw in DrawObjects.ToList()) {
					if (draw is VerticalLine && draw.Tag.Contains("HighlightMyDateTime_") == true) {
						this.RemoveDrawObject(draw.Tag);
					}
				}
				using (TextFieldParser parser = new TextFieldParser(csvFile))
				{
				    parser.TextFieldType = FieldType.Delimited;
				    parser.SetDelimiters(",");
				    while (!parser.EndOfData)
				    {
						DateTime csvVerticalLineDateTime;
				        string[] fields = parser.ReadFields();
						try {
							csvVerticalLineDateTime = DateTime.ParseExact(fields[0], "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
						}
						catch (FormatException) {
							continue;
						}
						Brush myBrush = (SolidColorBrush)(new BrushConverter().ConvertFrom(fields[2]));
						myBrush.Opacity = (Double.Parse(fields[5]) / 100);
						Draw.VerticalLine(this, fields[1], csvVerticalLineDateTime, myBrush, (DashStyleHelper)Enum.ToObject(typeof(DashStyleHelper),Int32.Parse(fields[3])), Int32.Parse(fields[4]), false);
				    }
				}
			}
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(Name="ModeMaster", Description="Master mode when true. Slave when false.", Order=1, GroupName="Parameters")]
		public bool ModeMaster
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="GroupID", Description="Master and Slaves group. Creates different CSV files per group, so you can attach multiple instances of this indicator.", Order=2, GroupName="Parameters")]
		public int GroupID
		{ get; set; }
		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MyIndicators.HighlightMyDateTime[] cacheHighlightMyDateTime;
		public MyIndicators.HighlightMyDateTime HighlightMyDateTime(bool modeMaster, int groupID)
		{
			return HighlightMyDateTime(Input, modeMaster, groupID);
		}

		public MyIndicators.HighlightMyDateTime HighlightMyDateTime(ISeries<double> input, bool modeMaster, int groupID)
		{
			if (cacheHighlightMyDateTime != null)
				for (int idx = 0; idx < cacheHighlightMyDateTime.Length; idx++)
					if (cacheHighlightMyDateTime[idx] != null && cacheHighlightMyDateTime[idx].ModeMaster == modeMaster && cacheHighlightMyDateTime[idx].GroupID == groupID && cacheHighlightMyDateTime[idx].EqualsInput(input))
						return cacheHighlightMyDateTime[idx];
			return CacheIndicator<MyIndicators.HighlightMyDateTime>(new MyIndicators.HighlightMyDateTime(){ ModeMaster = modeMaster, GroupID = groupID }, input, ref cacheHighlightMyDateTime);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MyIndicators.HighlightMyDateTime HighlightMyDateTime(bool modeMaster, int groupID)
		{
			return indicator.HighlightMyDateTime(Input, modeMaster, groupID);
		}

		public Indicators.MyIndicators.HighlightMyDateTime HighlightMyDateTime(ISeries<double> input , bool modeMaster, int groupID)
		{
			return indicator.HighlightMyDateTime(input, modeMaster, groupID);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MyIndicators.HighlightMyDateTime HighlightMyDateTime(bool modeMaster, int groupID)
		{
			return indicator.HighlightMyDateTime(Input, modeMaster, groupID);
		}

		public Indicators.MyIndicators.HighlightMyDateTime HighlightMyDateTime(ISeries<double> input , bool modeMaster, int groupID)
		{
			return indicator.HighlightMyDateTime(input, modeMaster, groupID);
		}
	}
}

#endregion
