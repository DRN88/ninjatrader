#region Using declarations
using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using Microsoft.VisualBasic.FileIO;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.MyIndicators
{
	public class FXStreetNews : Indicator
	{
		List<DateTime> newsDate = new List<DateTime>();
		List<String> newsName = new List<String>();
		List<String> newsCountry = new List<String>();
		List<int> newsImpact = new List<int>();
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Loads FXStreet downloaded csv data and displays vertical lines for news events.";
				Name										= "FXStreetNews";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				IsAutoScale									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				CSVFile										= @"C:\DATA\eventdates.csv";
				LowImpactColor								= Brushes.Yellow;
				ModerateImpactColor							= Brushes.Orange;
				HighImpactColor								= Brushes.Red;
				ImpactColorOpacity							= 0.4;
				ImpactStyle									= DashStyleHelper.Solid;
			}
			else if (State == State.Configure)
			{
				using (TextFieldParser parser = new TextFieldParser(CSVFile))
				{
				    parser.TextFieldType = FieldType.Delimited;
				    parser.SetDelimiters(",");
				    while (!parser.EndOfData)
				    {
				        string[] fields = parser.ReadFields();
						try {
							newsDate.Add(TimeZoneInfo.ConvertTimeFromUtc(DateTime.ParseExact(fields[0], "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture), TimeZoneInfo.Local));
							//Print(TimeZoneInfo.ConvertTimeFromUtc(DateTime.ParseExact(fields[0], "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture), TimeZoneInfo.Local));
						}
						catch (FormatException) {
							continue;
							//Print("Invalid datetime format. Please fix");
						}
						newsName.Add(fields[1]);
						newsCountry.Add(fields[2]);
						newsImpact.Add(int.Parse(fields[3]));
				    }

				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			// call the base.OnRender() to ensure standard Plots work as designed
			base.OnRender(chartControl, chartScale);
			int index = 0;
			foreach (var mynewsdate in newsDate) {
				//Print("eee: " + news + "  lal: " + newsCountry[index]);
				Brush ImpactBrush = Brushes.Transparent;
				switch (newsImpact[index]) {
					case 1:
						ImpactBrush = LowImpactColor.Clone(); ImpactBrush.Opacity = ImpactColorOpacity; break;
					case 2:
						ImpactBrush = ModerateImpactColor.Clone(); ImpactBrush.Opacity = ImpactColorOpacity; break;
					case 3:
						ImpactBrush = HighImpactColor.Clone(); ImpactBrush.Opacity = ImpactColorOpacity; break;
				}
				Draw.VerticalLine(this, newsName[index] + "_" + newsCountry[index] + "_" + newsImpact[index].ToString() + "_" + mynewsdate, mynewsdate, ImpactBrush, ImpactStyle, newsImpact[index], false);
				index++;
			}
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(Name="CSVFile", Description="Path to FXStreet CSV data file", Order=1, GroupName="Parameters")]
		public string CSVFile
		{ get; set; }
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="LowImpactColor", Order=10, GroupName="Parameters")]
		public Brush LowImpactColor
		{ get; set; }
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="ModerateImpactColor", Order=11, GroupName="Parameters")]
		public Brush ModerateImpactColor
		{ get; set; }
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="HighImpactColor", Order=12, GroupName="Parameters")]
		public Brush HighImpactColor
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="ImpactColorOpacity", Order=13, GroupName="Parameters")]
		public double ImpactColorOpacity
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="ImpactStyle", Order=14, GroupName="Parameters")]
		public DashStyleHelper ImpactStyle
		{ get; set; }
		
		[Browsable(false)]
		public string LowImpactColorSerializable
		{
			get { return Serialize.BrushToString(LowImpactColor); }
			set { LowImpactColor = Serialize.StringToBrush(value); }
		}
	
		[Browsable(false)]
		public string ModerateImpactColorSerializable
		{
			get { return Serialize.BrushToString(ModerateImpactColor); }
			set { ModerateImpactColor = Serialize.StringToBrush(value); }
		}
		
		[Browsable(false)]
		public string HighImpactColorSerializable
		{
			get { return Serialize.BrushToString(HighImpactColor); }
			set { HighImpactColor = Serialize.StringToBrush(value); }
		}
		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MyIndicators.FXStreetNews[] cacheFXStreetNews;
		public MyIndicators.FXStreetNews FXStreetNews(string cSVFile, Brush lowImpactColor, Brush moderateImpactColor, Brush highImpactColor, double impactColorOpacity, DashStyleHelper impactStyle)
		{
			return FXStreetNews(Input, cSVFile, lowImpactColor, moderateImpactColor, highImpactColor, impactColorOpacity, impactStyle);
		}

		public MyIndicators.FXStreetNews FXStreetNews(ISeries<double> input, string cSVFile, Brush lowImpactColor, Brush moderateImpactColor, Brush highImpactColor, double impactColorOpacity, DashStyleHelper impactStyle)
		{
			if (cacheFXStreetNews != null)
				for (int idx = 0; idx < cacheFXStreetNews.Length; idx++)
					if (cacheFXStreetNews[idx] != null && cacheFXStreetNews[idx].CSVFile == cSVFile && cacheFXStreetNews[idx].LowImpactColor == lowImpactColor && cacheFXStreetNews[idx].ModerateImpactColor == moderateImpactColor && cacheFXStreetNews[idx].HighImpactColor == highImpactColor && cacheFXStreetNews[idx].ImpactColorOpacity == impactColorOpacity && cacheFXStreetNews[idx].ImpactStyle == impactStyle && cacheFXStreetNews[idx].EqualsInput(input))
						return cacheFXStreetNews[idx];
			return CacheIndicator<MyIndicators.FXStreetNews>(new MyIndicators.FXStreetNews(){ CSVFile = cSVFile, LowImpactColor = lowImpactColor, ModerateImpactColor = moderateImpactColor, HighImpactColor = highImpactColor, ImpactColorOpacity = impactColorOpacity, ImpactStyle = impactStyle }, input, ref cacheFXStreetNews);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MyIndicators.FXStreetNews FXStreetNews(string cSVFile, Brush lowImpactColor, Brush moderateImpactColor, Brush highImpactColor, double impactColorOpacity, DashStyleHelper impactStyle)
		{
			return indicator.FXStreetNews(Input, cSVFile, lowImpactColor, moderateImpactColor, highImpactColor, impactColorOpacity, impactStyle);
		}

		public Indicators.MyIndicators.FXStreetNews FXStreetNews(ISeries<double> input , string cSVFile, Brush lowImpactColor, Brush moderateImpactColor, Brush highImpactColor, double impactColorOpacity, DashStyleHelper impactStyle)
		{
			return indicator.FXStreetNews(input, cSVFile, lowImpactColor, moderateImpactColor, highImpactColor, impactColorOpacity, impactStyle);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MyIndicators.FXStreetNews FXStreetNews(string cSVFile, Brush lowImpactColor, Brush moderateImpactColor, Brush highImpactColor, double impactColorOpacity, DashStyleHelper impactStyle)
		{
			return indicator.FXStreetNews(Input, cSVFile, lowImpactColor, moderateImpactColor, highImpactColor, impactColorOpacity, impactStyle);
		}

		public Indicators.MyIndicators.FXStreetNews FXStreetNews(ISeries<double> input , string cSVFile, Brush lowImpactColor, Brush moderateImpactColor, Brush highImpactColor, double impactColorOpacity, DashStyleHelper impactStyle)
		{
			return indicator.FXStreetNews(input, cSVFile, lowImpactColor, moderateImpactColor, highImpactColor, impactColorOpacity, impactStyle);
		}
	}
}

#endregion
