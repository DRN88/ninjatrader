#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.MyIndicators
{
	public class PriorWeekOHLC : Indicator
	{
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "PriorWeekOHLC";
				Calculate									= Calculate.OnBarClose;
				IsAutoScale									= false;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive					= true;
				ShowPriorWeekOpen							= true;
				ShowPriorWeekHigh							= true;
				ShowPriorWeekLow							= true;
				ShowPriorWeekClose							= true;
				AddPlot(new Stroke(Brushes.DarkGoldenrod, DashStyleHelper.Solid, 2), PlotStyle.Square, "PriorWeekOpen");
				AddPlot(new Stroke(Brushes.DarkGreen, DashStyleHelper.Solid, 2), PlotStyle.Square, "PriorWeekHigh");
				AddPlot(new Stroke(Brushes.IndianRed, DashStyleHelper.Solid, 2), PlotStyle.Square, "PriorWeekLow");
				AddPlot(new Stroke(Brushes.DarkRed, DashStyleHelper.Solid, 2), PlotStyle.Square, "PriorWeekClose");
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Week, 1);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBars[1] < 0) { return; }
			if (ShowPriorWeekOpen)  { Values[0][0] = Opens[1][0];  }
			if (ShowPriorWeekHigh)  { Values[1][0] = Highs[1][0];  }
			if (ShowPriorWeekLow)   { Values[2][0] = Lows[1][0];   }
			if (ShowPriorWeekClose) { Values[3][0] = Closes[1][0]; }
		}

		#region Properties
		[NinjaScriptProperty]
		[Display(Name="ShowPriorWeekOpen", Order=1, GroupName="Parameters")]
		public bool ShowPriorWeekOpen
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="ShowPriorWeekHigh", Order=2, GroupName="Parameters")]
		public bool ShowPriorWeekHigh
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="ShowPriorWeekLow", Order=3, GroupName="Parameters")]
		public bool ShowPriorWeekLow
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="ShowPriorWeekClose", Order=4, GroupName="Parameters")]
		public bool ShowPriorWeekClose
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Open
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> High
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Low
		{
			get { return Values[2]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Close
		{
			get { return Values[3]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MyIndicators.PriorWeekOHLC[] cachePriorWeekOHLC;
		public MyIndicators.PriorWeekOHLC PriorWeekOHLC(bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose)
		{
			return PriorWeekOHLC(Input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose);
		}

		public MyIndicators.PriorWeekOHLC PriorWeekOHLC(ISeries<double> input, bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose)
		{
			if (cachePriorWeekOHLC != null)
				for (int idx = 0; idx < cachePriorWeekOHLC.Length; idx++)
					if (cachePriorWeekOHLC[idx] != null && cachePriorWeekOHLC[idx].ShowPriorWeekOpen == showPriorWeekOpen && cachePriorWeekOHLC[idx].ShowPriorWeekHigh == showPriorWeekHigh && cachePriorWeekOHLC[idx].ShowPriorWeekLow == showPriorWeekLow && cachePriorWeekOHLC[idx].ShowPriorWeekClose == showPriorWeekClose && cachePriorWeekOHLC[idx].EqualsInput(input))
						return cachePriorWeekOHLC[idx];
			return CacheIndicator<MyIndicators.PriorWeekOHLC>(new MyIndicators.PriorWeekOHLC(){ ShowPriorWeekOpen = showPriorWeekOpen, ShowPriorWeekHigh = showPriorWeekHigh, ShowPriorWeekLow = showPriorWeekLow, ShowPriorWeekClose = showPriorWeekClose }, input, ref cachePriorWeekOHLC);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MyIndicators.PriorWeekOHLC PriorWeekOHLC(bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose)
		{
			return indicator.PriorWeekOHLC(Input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose);
		}

		public Indicators.MyIndicators.PriorWeekOHLC PriorWeekOHLC(ISeries<double> input , bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose)
		{
			return indicator.PriorWeekOHLC(input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MyIndicators.PriorWeekOHLC PriorWeekOHLC(bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose)
		{
			return indicator.PriorWeekOHLC(Input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose);
		}

		public Indicators.MyIndicators.PriorWeekOHLC PriorWeekOHLC(ISeries<double> input , bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose)
		{
			return indicator.PriorWeekOHLC(input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose);
		}
	}
}

#endregion
